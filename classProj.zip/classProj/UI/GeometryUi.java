package UI;

import oop.Geometry;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GeometryUi {
    //creating JFrame elements for Geometry UI
    JFrame frame = new JFrame("Geometry");
    JButton areaOfSqBtn = new JButton("Area of square:");
    JButton areaOfTriangle = new JButton("Area of triangle");
    JButton areaOfRectangle = new JButton("Area of rectangle");

    public void mainUI() {
        frame.add(areaOfSqBtn);
        frame.add(areaOfTriangle);
        frame.add(areaOfRectangle);
        frame.setSize(150, 200);
        frame.setLayout(new GridLayout(3, 1));
        frame.setVisible(true);


        areaOfSqBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Calculate area of square");
                //JOptionPane.showMessageDialog(null, "Calculate area of Square");
                drawAreaOfSquareUI();
            }
        });
    }
        JFrame areaOfSquareFrame = new JFrame("Area of square");
        JTextField enterLengthOfSquare = new JTextField("Enter length");
        JButton calculateAreaOfSquare = new JButton("Calculate");
        public void drawAreaOfSquareUI() {
            Geometry geometry = new Geometry();
            areaOfSquareFrame.add(enterLengthOfSquare);
            areaOfSquareFrame.add(calculateAreaOfSquare);
            areaOfSquareFrame.setLayout(new GridLayout(2, 1));
            areaOfSquareFrame.setSize(100, 200);
            areaOfSquareFrame.setVisible(true);

            frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

            areaOfSqBtn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    float area = geometry.areaOfSquare(Float.parseFloat(enterLengthOfSquare.getText()));
                }
            });
        }
    }