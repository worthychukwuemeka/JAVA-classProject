package oop;

import UI.GeometryUi;


public class OOPMain {
    public static void main(String[] args) {
        GeometryUi geometry = new GeometryUi();
        geometry.mainUI();
    }
}

//read & write to file.