package DatatypesAndVariables;

public class FloatDouble {
    public static void main(String[] args) {
        float f = 10f/6f;
        double d = 10d/6d;
        System.out.println(f);
        System.out.println(d);
    }
}
