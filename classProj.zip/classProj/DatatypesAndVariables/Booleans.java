package DatatypesAndVariables;

public class Booleans {
    public static void main(String[] args) {
        boolean value = 1==2;
        System.out.println(value);

        char value2 = '&';
        System.out.println(value2);
    }
}
