### Documenting Java Classes

#### Variables and data types

#### 
